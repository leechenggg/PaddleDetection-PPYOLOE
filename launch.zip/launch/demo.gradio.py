import gradio as gr
import fastdeploy as fd
import cv2

# 初始化预测模型
import fastdeploy as fd
import cv2

option = fd.RuntimeOption()
option.use_gpu()
model = fd.vision.detection.PPYOLOE("/home/aistudio/PaddleDetection/output_inference/ppyoloe_crn_l_300e_coco/model.pdmodel", "/home/aistudio/PaddleDetection/output_inference/ppyoloe_crn_l_300e_coco/model.pdiparams", "/home/aistudio/PaddleDetection/output_inference/ppyoloe_crn_l_300e_coco/infer_cfg.yml", runtime_option=option)

def infer(image):
    result = model.predict(image)
    vis_im = fd.vision.vis_detection(image, result, labels=["crazing","inclusion","patches","pitted_surface","rolled-in_scale","scratches"],score_threshold=0.4)
    return vis_im

demo = gr.Interface(fn=infer, title="钢铁缺陷检测", inputs=gr.Image(), outputs="image")
demo.launch()
